import { Component, OnInit } from '@angular/core';
import { AuthGuard } from 'src/app/auth.service';
import { SessionService } from 'src/app/services/session.service';
import { Router } from '@angular/router';
import { DashboardItem,DashboardService } from 'src/app/services/app-url-data.service';
import {  ElementRef, Renderer2, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  isDisabled: boolean = true; 
  dashboardItems: DashboardItem[] = [];
  constructor(private authGuard: AuthGuard,private sessionService: SessionService, private router: Router,private dashboardService: DashboardService,private elementRef: ElementRef, private renderer: Renderer2) {}
  

  ngOnInit(): void {
    this.getDashboardItems();
  }

  getDashboardItems(): void {
    this.dashboardService.getDashboardItems()
      .subscribe(items => {
        this.dashboardItems = items;
      });
  }
  logout(): void {
    this.sessionService.clearSession(); // Clear session in SessionService
    // Clear login data from localStorage
    sessionStorage.removeItem('loggedIn');
    sessionStorage.removeItem('userId');
    sessionStorage.removeItem('encryptedPassword');
    sessionStorage.removeItem('channelType');
    this.router.navigate(['fgApp/login']);

    // Set the logout flag when the user logs out
    this.authGuard.setLoggedOutFlag();

    // ... other code ...
  }



//Block access to hyperlink when url is not provided
  handleClick(event: MouseEvent, url: string): void {
    if (!url || url === '') {
      event.preventDefault();
    //  console.log('Link is disabled.');
      // Perform any other action needed when the link is disabled
    }
  }
  ngAfterViewInit(): void {
    this.handleTouch();
  }

  handleTouch(): void {
    const isTouchDevice = 'ontouchstart' in document.documentElement;

    if (isTouchDevice) {
      const boxFooters = this.elementRef.nativeElement.querySelectorAll('.box-footer');

      boxFooters.forEach((footer: HTMLElement) => {
        this.renderer.listen(footer, 'click', (event) => {
          const boxIcons = footer.closest('.box')?.querySelector('.box-icons');
          if (boxIcons) {
            boxIcons.classList.toggle('show-icons');
          }
          event.stopPropagation();
        });
      });
    }
  }





// To track the last opened collapsible item
  lastOpened: any = null; 
  // Function to toggle collapsible elements
  toggleCollapsible(item: any) {
    const checkbox = document.getElementById(item.title) as HTMLInputElement;
    // If the clicked item is different from the last opened, close the last opened collapsible
    if (this.lastOpened && this.lastOpened !== checkbox) {
      this.lastOpened.checked = false;
    }
    // Toggle the clicked collapsible
    checkbox.checked = !checkbox.checked;
    // Update the last opened collapsible
    this.lastOpened = checkbox.checked ? checkbox : null;
  }
  

}
