import { Component } from '@angular/core';

@Component({
  selector: 'app-fg-app-list',
  templateUrl: './fg-app-list.component.html',
  styleUrls: ['./fg-app-list.component.css']
})
export class FgAppListComponent {

}
